<?php

namespace App\Http\Controllers;

use App\Support\PublicImagePath;
use App\Http\Controllers\Admin\StatistikController;
use App\Models\Berita;
use Illuminate\Support\Facades\File;
use Throwable;

class BerandaController extends Controller
{
    public function index()
    {
        // 1. Statistik Dasawisma — definisi hardcoded, hanya angka dari DB.
        $statistik = collect(StatistikController::getStatistikData())->map(function ($item) {
            return [
                'judul' => $item['judul'],
                'nilai' => $item['nilai'] === null ? null : number_format((float) $item['nilai'], 0, ',', '.'),
                'satuan' => $item['satuan'],
                'deskripsi' => $item['deskripsi'],
                'warna' => $item['warna'],
                'icon' => $item['icon'],
            ];
        })->all();

        // 2. Daftar Kegiatan PKK Terbaru dari Database Berita
        $badgeColors = [
            'Umum' => 'bg-amber-100 text-amber-800',
            'Pokja I' => 'bg-purple-100 text-purple-800',
            'Pokja II' => 'bg-blue-100 text-blue-800',
            'Pokja III' => 'bg-teal-100 text-teal-800',
            'Pokja IV' => 'bg-emerald-100 text-emerald-800',
        ];

        $kegiatan = [];
        $galeri = [];

        try {
            $kegiatan = Berita::where('status', 'published')
                ->latest('tanggal')
                ->take(8)
                ->get(['id', 'judul', 'kategori', 'tanggal', 'ringkasan', 'gambar'])
                ->map(function ($item) use ($badgeColors) {
                    return [
                        'id' => $item->id,
                        'judul' => $item->judul,
                        'kategori' => $item->kategori,
                        'badge_color' => $badgeColors[$item->kategori] ?? 'bg-emerald-100 text-emerald-800',
                        'tanggal' => $item->tanggal_formatted,
                        'ringkasan' => $item->ringkasan,
                        'gambar' => $item->gambar,
                    ];
                })->all();

            $galeri = Berita::where('status', 'published')
                ->whereNotNull('gambar')
                ->latest('tanggal')
                ->take(8)
                ->get(['id', 'gambar', 'judul', 'kategori', 'tanggal'])
                ->map(function ($item) {
                    return [
                        'id' => $item->id,
                        'gambar' => $item->gambar,
                        'judul' => $item->judul,
                        'kategori' => $item->kategori,
                        'tanggal' => $item->tanggal_formatted,
                    ];
                })->all();
        } catch (Throwable $e) {
            // Jika database belum termigrasi atau koneksi gagal, kembalikan array kosong
            $kegiatan = [];
            $galeri = [];
        }

        // 3. 4 Kelompok Kerja (Pokja) PKK
        $pokja = [
            [
                'kode' => 'Pokja 1',
                'nama' => 'Penghayatan Pengamalan & Gotong Royong',
                'deskripsi' => 'Pembinaan kesadaran bela negara, penghayatan Pancasila, kegiatan gotong royong, bakti sosial, dan dermawan sosial.',
                'icon' => 'fa-solid fa-hands-holding-child',
            ],
            [
                'kode' => 'Pokja 2',
                'nama' => 'Pendidikan, Keterampilan & UP2K',
                'deskripsi' => 'Meningkatkan mutu pendidikan keluarga, pelatihan keterampilan, dan Usaha Peningkatan Pendapatan Keluarga (UP2K).',
                'icon' => 'fa-solid fa-book-open-reader',
            ],
            [
                'kode' => 'Pokja 3',
                'nama' => 'Pangan, Sandang & Tata Laksana Rumah',
                'deskripsi' => 'Ketahanan pangan lokal (Hatinya PKK), busana sopan dan layak, serta tata laksana rumah tangga yang sehat dan asri.',
                'icon' => 'fa-solid fa-utensils',
            ],
            [
                'kode' => 'Pokja 4',
                'nama' => 'Kesehatan & Lingkungan Hidup',
                'deskripsi' => 'Pengelolaan posyandu, pencegahan stunting, perilaku hidup bersih dan sehat (PHBS), serta pelestarian lingkungan.',
                'icon' => 'fa-solid fa-heart-pulse',
            ],
        ];

        // 4. Foto Hero Background Beranda (Dapat diatur dari CMS Admin)
        $heroBackground = 'images/5.webp';
        try {
            $profilPath = storage_path('app/profil_data.json');
            if (File::exists($profilPath)) {
                $profilData = json_decode(File::get($profilPath), true) ?? [];
                $customHero = $profilData['hero_background'] ?? null;
                if (is_string($customHero)
                    && str_starts_with($customHero, 'images/hero/')
                    && ! str_contains($customHero, '..')
                    && File::exists(PublicImagePath::file($customHero))) {
                    $heroBackground = $customHero;
                }
            }
        } catch (Throwable $e) {
            $heroBackground = 'images/5.webp';
        }

        return view('beranda', compact('statistik', 'kegiatan', 'pokja', 'galeri', 'heroBackground'));
    }
}
